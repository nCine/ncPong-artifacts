[![Linux](https://github.com/nCine/ncPong/workflows/Linux/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncPong/workflows/macOS/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncPong/workflows/Windows/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncPong/workflows/MinGW/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncPong/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncPong/workflows/Android/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncPong/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncPong/actions?workflow=CodeQL)

# ncPong
ncPong is an example game made with the nCine.  
You can control the stick with the mouse on PC, tapping the screen on Android or with the joystick on both platforms.
